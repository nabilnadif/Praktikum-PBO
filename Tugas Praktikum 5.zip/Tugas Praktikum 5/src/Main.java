public class Main {
    public static void main(String[] args) {
        // Membuat 3 Objek
        // 1. Objek ini akan memanggil constructor pertama
        Transaksi beliBuku = new Transaksi("Buku Tulis", 5, 5000.0);
        beliBuku.tampilkanInfo();
        System.out.println("-> Harga Total: Rp" + beliBuku.hitungTotal());
        System.out.println("-> Total (Diskon 10%): Rp" + beliBuku.hitungTotal(10));
        System.out.println();

        // 2. Objek ini akan memanggil constructor kedua yang sudah diubah
        Transaksi beliPulpen = new Transaksi("Pulpen", 3000.0);
        beliPulpen.tampilkanInfo();
        System.out.println("-> Harga Total: Rp" + beliPulpen.hitungTotal());
        System.out.println();

        // 3. Objek lain dengan constructor pertama
        Transaksi beliKopi = new Transaksi("Kopi Sachet", 2, 2500.0);
        beliKopi.tampilkanInfo();
        System.out.println("-> Harga Total: Rp" + beliKopi.hitungTotal());
    }
}