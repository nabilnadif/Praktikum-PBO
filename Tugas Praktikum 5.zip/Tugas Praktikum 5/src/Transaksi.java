public class Transaksi {
    // Atribut
    String namaBarang;
    int jumlah;
    double hargaSatuan;

    // Constructor Overloading
    // 1. Constructor untuk membeli lebih dari satu barang
    public Transaksi(String barang, int jumlah, double harga) {
        this.namaBarang = barang;
        this.jumlah = jumlah;
        this.hargaSatuan = harga;
    }

    // 2. Constructor untuk membeli SATU barang saja
    public Transaksi(String barang, double harga) {
        this.namaBarang = barang;
        this.jumlah = 1;
        this.hargaSatuan = harga;
    }

    // Method Overloading
    // 1. Hitung total harga normal
    public double hitungTotal() {
        return jumlah * hargaSatuan;
    }

    // 2. Hitung total harga dengan diskon (misal: 10 untuk 10%)
    public double hitungTotal(double diskonPersen) {
        double totalAwal = hitungTotal();
        double diskon = totalAwal * (diskonPersen / 100);
        return totalAwal - diskon;
    }

    // Method untuk menampilkan info
    public void tampilkanInfo() {
        System.out.println("Barang: " + this.namaBarang + ", Jumlah: " + this.jumlah);
    }
}