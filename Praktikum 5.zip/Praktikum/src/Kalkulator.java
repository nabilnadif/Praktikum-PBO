public class Kalkulator {
    // Method untuk integer
    public int tambah(int a, int b){
        System.out.println("Menambah integer");
        return a+b;
    }

    // Method untuk double
    public  double tambah(double a, double b){
        System.out.println("Menambah double");
        return a+b;
    }

    // Method untuk String (concatenation)
    public String tambah(String a, String b){
        System.out.println("Menambah string");
        return a+b;
    }
}
